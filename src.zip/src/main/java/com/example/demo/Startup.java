package com.example.demo;

public class Startup {
    public static void main(String[] args) {
        // 调用之前的那个 JavaFX 启动类
        DesktopLauncher.main(args);
    }
}